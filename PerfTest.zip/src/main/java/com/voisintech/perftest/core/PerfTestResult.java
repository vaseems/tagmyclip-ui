package com.voisintech.perftest.core;

public class PerfTestResult {
	private String pingResult = "";
	private String traceRouteResult = "";
	private String ipconfigResult = "";
	private String netstatResult = "";

	private Long pingTimeTaken;
	private Long traceRouteTimeTaken;
	private boolean ping = false;
	private boolean traceRoute = false;
	private boolean ipConfig = false;
	private boolean netstat = false;
	
	public String getPingResult() {
		return pingResult;
	}

	public void setPingResult(String result) {
		this.pingResult = result;
	}

	public String getTraceRouteResult() {
		return traceRouteResult;
	}

	public void setTraceRouteResult(String result) {
		this.traceRouteResult = result;
	}

	public String getIpconfigResult() {
		return ipconfigResult;
	}

	public void setIpconfigResult(String result) {
		this.ipconfigResult = result;
	}

	public String getNetstatResult() {
		return netstatResult;
	}

	public void setNetstatResult(String result) {
		this.netstatResult = result;
	}

	public Long getPingTimeTaken() {
		return pingTimeTaken;
	}

	public void setPingTimeTaken(Long pingTimeTaken) {
		this.pingTimeTaken = pingTimeTaken;
	}

	public Long getTraceRouteTimeTaken() {
		return traceRouteTimeTaken;
	}

	public void setTraceRouteTimeTaken(Long traceRouteTimeTaken) {
		this.traceRouteTimeTaken = traceRouteTimeTaken;
	}

	public boolean isPing() {
		return ping;
	}

	public void setPing(boolean ping) {
		this.ping = ping;
	}

	public boolean isTraceRoute() {
		return traceRoute;
	}

	public void setTraceRoute(boolean traceRoute) {
		this.traceRoute = traceRoute;
	}

	public boolean isIpConfig() {
		return ipConfig;
	}

	public void setIpConfig(boolean ipConfig) {
		this.ipConfig = ipConfig;
	}

	public boolean isNetstat() {
		return netstat;
	}

	public void setNetstat(boolean netstat) {
		this.netstat = netstat;
	}
	
	public String getResultType(){
		return isPing()?"PING":isTraceRoute()?"TraceRoute":isIpConfig()?"IPConfig":"Netstat";
	}
	public String getResult(){
		return isPing()?getPingResult():isTraceRoute()?getTraceRouteResult():isIpConfig()?getIpconfigResult():getNetstatResult();
	}
}
