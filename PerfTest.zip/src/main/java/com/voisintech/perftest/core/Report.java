package com.voisintech.perftest.core;

public class Report {
	private String date;
	private String time;
	private String author;
	private String department;
	private String performance;
	private String resultType;
	private String resultText;
	private String address;
	private Integer index;
	private String min;
	private String avg;
	private String max;
	private String mdev;
	private String total;
	private String showGraph;
	private String pings;
	private String tracers;
	private String version;
	private String source;
	private String destination;
	private String description;
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getPerformance() {
		return performance;
	}

	public void setPerformance(String performance) {
		this.performance = performance;
	}

	public String getResultType() {
		return resultType;
	}

	public void setResultType(String resultType) {
		this.resultType = resultType;
	}

	public String getResultText() {
		return resultText;
	}

	public void setResultText(String resultText) {
		this.resultText = resultText;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getIndex() {
		return index;
	}

	public void setIndex(Integer index) {
		this.index = index;
	}

	public String getMin() {
		return min;
	}

	public void setMin(String min) {
		this.min = min;
	}

	public String getAvg() {
		return avg;
	}

	public void setAvg(String avg) {
		this.avg = avg;
	}

	public String getMax() {
		return max;
	}

	public void setMax(String max) {
		this.max = max;
	}

	public String getMdev() {
		return mdev;
	}

	public void setMdev(String mdev) {
		this.mdev = mdev;
	}

	public String getTotal() {
		return total;
	}

	public void setTotal(String total) {
		this.total = total;
	}

	public String getShowGraph() {
		return showGraph;
	}

	public void setShowGraph(String showGraph) {
		this.showGraph = showGraph;
	}

	public String getPings() {
		return pings;
	}

	public void setPings(String pings) {
		this.pings = pings;
	}

	public String getTracers() {
		return tracers;
	}

	public void setTracers(String tracers) {
		this.tracers = tracers;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
