package com.voisintech.perftest.core;

public interface Task {
	PerfTestResult execute();
}
