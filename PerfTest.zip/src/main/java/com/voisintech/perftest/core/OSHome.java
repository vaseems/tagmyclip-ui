package com.voisintech.perftest.core;

public class OSHome {

	private static String OS = System.getProperty("os.name").toLowerCase();

	public static String getPerfTestPath() {
		return isWindows()?"C:":System.getProperty("user.home") + "/PerfTest";
	}

	public static boolean isWindows() {
		return OS.equalsIgnoreCase("win");

	}

	public static boolean isUnix() {
		return OS.equalsIgnoreCase("linux");
	}

}
