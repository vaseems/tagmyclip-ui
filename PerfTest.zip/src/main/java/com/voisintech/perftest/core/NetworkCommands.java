package com.voisintech.perftest.core;

public interface NetworkCommands {
	public String UNIX_PING = "ping -c 15 ";
	public String UNIX_TRACEROUTE = "traceroute ";
	public String UNIX_IPCONFIG = "ifconfig -a";
	public String UNIX_NETSTAT = "netstat -r";
	public String WIN_PING = "ping -n 15";
	public String WIN_TRACEROUTE = "tracert ";
	public String WIN_IPCONFIG = "ipconfig /all";
	public String WIN_NETSTAT = "netstat -r";
}
