package com.voisintech.perftest.core;

import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.MethodInvocationException;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;

public class TemplateEngine {

	private static VelocityEngine velocityEngine;

	public static void init() throws Exception {
		if (velocityEngine == null) {
			velocityEngine = new VelocityEngine();
			velocityEngine.setProperty(RuntimeConstants.RESOURCE_LOADER,
					"classpath");
			velocityEngine.setProperty("classpath.resource.loader.class",
					ClasspathResourceLoader.class.getName());
			velocityEngine.init();
		}
	}

	public static String buildContent(Report request, String templateName)
			throws ParseErrorException, MethodInvocationException, Exception {
		init();
		VelocityContext context = new VelocityContext();
		context.put("model", request);
		context.put("date",
				new SimpleDateFormat("EEEE, dd MMMM yyyy").format(new Date()));
		StringWriter writer = new StringWriter();
		velocityEngine.mergeTemplate(templateName, "UTF-8", context, writer);
		return writer.toString();
	}
}
