package com.voisintech.perftest.tasks.receiver;

/**
 * @author vaseem
 *
 */
public interface TaskReceiver {
	String ping(String ipAddress);
	String traceroute(String ipAddress);
	String ipconfig();
	String netstat();
}
