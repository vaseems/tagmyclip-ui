package com.voisintech.perftest.tasks;

import com.voisintech.perftest.PerfTest;
import com.voisintech.perftest.core.PerfTestResult;
import com.voisintech.perftest.core.Task;
import com.voisintech.perftest.tasks.receiver.TaskReceiver;

public class Netstat implements Task {

	private TaskReceiver task;

	public Netstat(TaskReceiver task){
		this.task = task;
	}
	
	public PerfTestResult execute() {
		PerfTestResult perfTestResult = PerfTest.finalResult.get("netstat");
		String netstat = task.netstat();
		perfTestResult.setNetstatResult(netstat.replaceAll("\n", "</div><div>"));
		perfTestResult.setNetstat(true);
		return perfTestResult;
	}
}
