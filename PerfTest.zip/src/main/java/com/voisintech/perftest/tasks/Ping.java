package com.voisintech.perftest.tasks;

import com.voisintech.perftest.PerfTest;
import com.voisintech.perftest.core.PerfTestResult;
import com.voisintech.perftest.core.Task;
import com.voisintech.perftest.tasks.receiver.TaskReceiver;

public class Ping implements Task {

	private TaskReceiver task;
	private String ipAddress;

	public Ping(TaskReceiver task, String ipAddress) {
		this.task = task;
		this.ipAddress = ipAddress;
	}

	public PerfTestResult execute() {
		PerfTestResult perfTestResult = PerfTest.finalResult.get("PING_"+ipAddress);
		String ping = task.ping(ipAddress);
		perfTestResult.setPingResult(format(ping));
		perfTestResult.setPing(true);
		return perfTestResult;
	}
	private String format(String pingData){
		String newPingData = pingData.replaceAll("received,", "received, <span style='color: red'>");
		newPingData = newPingData.replaceAll("packet loss,","packet loss</span>,");
		return newPingData.replaceAll("\n", "</div>\n<div>");
	}
}
