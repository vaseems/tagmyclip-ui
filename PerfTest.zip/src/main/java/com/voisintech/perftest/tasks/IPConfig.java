package com.voisintech.perftest.tasks;

import com.voisintech.perftest.PerfTest;
import com.voisintech.perftest.core.PerfTestResult;
import com.voisintech.perftest.core.Task;
import com.voisintech.perftest.tasks.receiver.TaskReceiver;

/**
 * @author vaseem
 *
 */
public class IPConfig implements Task {

	private TaskReceiver task;

	public IPConfig(TaskReceiver task){
		this.task = task;
	}
	
	public PerfTestResult execute() {
		PerfTestResult perfTestResult = PerfTest.finalResult.get("ipconfig");
		String ipconfig = task.ipconfig();
		perfTestResult.setIpconfigResult(ipconfig.replaceAll("\n", "</div><div>"));
		perfTestResult.setIpConfig(true);
		return perfTestResult;
	}

}
