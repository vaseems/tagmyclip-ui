package com.voisintech.perftest.tasks.receiver;

import com.voisintech.perftest.core.InetUtils;
import com.voisintech.perftest.core.NetworkCommands;

/**
 * @author vaseem
 *
 */
public class WindowsTaskReceiver implements TaskReceiver, NetworkCommands {

	public String ping(String ipAddress) {
		return InetUtils.executeCommand(WIN_PING + ipAddress);
	}

	public String traceroute(String ipAddress) {
		return InetUtils.executeCommand(WIN_TRACEROUTE + ipAddress);
	}

	public String ipconfig() {
		return InetUtils.executeCommand(WIN_IPCONFIG);
	}

	public String netstat() {
		return InetUtils.executeCommand(WIN_NETSTAT);
	}
}
