package com.voisintech.perftest.tasks.receiver;

import java.util.concurrent.Callable;

import com.voisintech.perftest.core.PerfTestResult;
import com.voisintech.perftest.core.Task;

public class TaskInvoker implements Callable<PerfTestResult> {
	private Task task;

	public TaskInvoker(Task task) {
		this.task = task;
	}

	public PerfTestResult call() throws Exception {
		return task.execute();
	}
}
