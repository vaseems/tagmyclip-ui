package com.voisintech.perftest.tasks.receiver;

public class Platform {
	public static TaskReceiver getUnderlyingTaskReceiver(){
		String osName = System.getProperty("os.name");
        if(osName.contains("Windows")){
            return new WindowsTaskReceiver();
        }else{
            return new UnixTaskReceiver();
        }
	}
}
