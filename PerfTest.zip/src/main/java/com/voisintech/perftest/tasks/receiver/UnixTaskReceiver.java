package com.voisintech.perftest.tasks.receiver;

import com.voisintech.perftest.core.InetUtils;
import com.voisintech.perftest.core.NetworkCommands;

/**
 * @author vaseem
 *
 */
public class UnixTaskReceiver implements TaskReceiver, NetworkCommands {

	public String ping(String ipAddress) {
		return InetUtils.executeCommand(UNIX_PING + ipAddress);
	}

	public String traceroute(String ipAddress) {
		return InetUtils.executeCommand(UNIX_TRACEROUTE + ipAddress);
	}

	public String ipconfig() {
		return InetUtils.executeCommand(UNIX_IPCONFIG);
	}

	public String netstat() {
		return InetUtils.executeCommand(UNIX_NETSTAT);
	}
}
