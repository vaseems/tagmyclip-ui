package com.voisintech.perftest.tasks;

import com.voisintech.perftest.PerfTest;
import com.voisintech.perftest.core.PerfTestResult;
import com.voisintech.perftest.core.Task;
import com.voisintech.perftest.tasks.receiver.TaskReceiver;

/**
 * @author vaseem
 *
 */
public class TraceRoute implements Task {

	private TaskReceiver task;
	private String ipAddress;
	public TraceRoute(TaskReceiver task, String ipAddress){
		this.task = task;
		this.ipAddress = ipAddress;
	}
	
	public PerfTestResult execute() {
		PerfTestResult perfTestResult = PerfTest.finalResult.get("TR_"+ipAddress);
		String traceRoute = task.traceroute(ipAddress);
		perfTestResult.setTraceRouteResult(format(traceRoute));
		perfTestResult.setTraceRoute(true);
		return perfTestResult;
	}
	private String format(String traceRoute){
		String newTraceRoute = traceRoute.replaceAll("received,", "received, <span style='color: red'>");
		newTraceRoute = newTraceRoute.replaceAll("packet loss,","packet loss</span>,");
		return newTraceRoute.replaceAll("\n", "</div><div>");
	}
}
