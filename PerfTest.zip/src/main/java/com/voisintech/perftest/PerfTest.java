package com.voisintech.perftest;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.voisintech.perftest.core.OSHome;
import com.voisintech.perftest.core.PerfTestResult;
import com.voisintech.perftest.core.Report;
import com.voisintech.perftest.core.TemplateEngine;
import com.voisintech.perftest.tasks.IPConfig;
import com.voisintech.perftest.tasks.Netstat;
import com.voisintech.perftest.tasks.Ping;
import com.voisintech.perftest.tasks.TraceRoute;
import com.voisintech.perftest.tasks.receiver.Platform;
import com.voisintech.perftest.tasks.receiver.TaskInvoker;
import com.voisintech.perftest.tasks.receiver.TaskReceiver;

public class PerfTest {

	public static Path perfTestLogFile;
	public static Map<String, PerfTestResult> finalResult;

	private final static Properties configProp = new Properties();
	private static StringBuilder progress;
	private static int percent = 0;
	private final static String[] performance = { "Performance is better than office hours",
			"Performance is slower than office hours", "No difference in performance post office hours", "I haven't checked the performance post office hours" };
	private final static String DEPARMENT = "IBM ISL Operations";
	private static final String AUTHOR = "Mohsin Abbas Mohammed";
	
	private static String[] pingResult;
	
	public static void main(String[] args) throws IOException,
			InterruptedException {

		Long startTime = Calendar.getInstance().getTimeInMillis();

		checkAndCreateLogFolder();
		checkAndCreateDefaultsProperties();

		finalResult = new HashMap<String, PerfTestResult>();

		System.out
				.println("Ensure BSO/BFS/NAD Authentication wherever applicable.");
		System.out.println("Enter destination IP Address: ");

		Scanner scanIn = new Scanner(System.in);
		String destAddress = scanIn.next();
		System.out.println(destAddress);

		System.out.println("Enter problem description.");
		String problemDescription = scanIn.next();
		System.out.println(problemDescription);

		System.out.println("How is the performane post office hours:\n"
				+ " 1. Better than office hours\n"
				+ " 2. Slower than office hours\n 3. No difference\n"
				+ " 4. Not checked\n 5. Exit");
		int choice = scanIn.nextInt();
		System.out.println(choice);

		if(choice>=5){
			scanIn.close();
			return;
		}
		List<Future<PerfTestResult>> listOfTasks = new ArrayList<Future<PerfTestResult>>();

		TaskReceiver taskReceiver = Platform.getUnderlyingTaskReceiver();

		StringTokenizer addresses = new StringTokenizer(destAddress, ",");
		StringTokenizer stPing = new StringTokenizer(configProp.get("ping")
				.toString(), ",");
		StringTokenizer stTraceRoute = new StringTokenizer(configProp.get(
				"traceroute").toString(), ",");

		ExecutorService executorService = Executors
				.newFixedThreadPool(addresses.countTokens() * 2);
		while (addresses.hasMoreElements()) {
			String address = (String) addresses.nextElement();
			finalResult.put("PING_" + address, new PerfTestResult());
			listOfTasks.add(executorService.submit(new TaskInvoker(new Ping(
					taskReceiver, address))));
			finalResult.put("TR_" + address, new PerfTestResult());
			listOfTasks.add(executorService.submit(new TaskInvoker(
					new TraceRoute(taskReceiver, address))));
		}

		while (stPing.hasMoreElements()) {
			String domain = (String) stPing.nextElement();
			finalResult.put("PING_" + domain, new PerfTestResult());
			listOfTasks.add(executorService.submit(new TaskInvoker(new Ping(
					taskReceiver, domain))));
		}

		while (stTraceRoute.hasMoreElements()) {
			String domain = (String) stTraceRoute.nextElement();
			finalResult.put("TR_" + domain, new PerfTestResult());
			listOfTasks.add(executorService.submit(new TaskInvoker(
					new TraceRoute(taskReceiver, domain))));
		}

		finalResult.put("ipconfig", new PerfTestResult());
		finalResult.put("netstat", new PerfTestResult());

		listOfTasks.add(executorService.submit(new TaskInvoker(new IPConfig(
				taskReceiver))));
		listOfTasks.add(executorService.submit(new TaskInvoker(new Netstat(
				taskReceiver))));

		executorService.shutdown();
		init();
		System.out.println("Please wait....");
		while (!executorService.isTerminated()) {
			if (percent < 100)
				update(percent++, 100);
			Thread.sleep(3000);
		}
		//

		BufferedWriter perfTestLogFile = new BufferedWriter(new FileWriter(
				PerfTest.perfTestLogFile.toString()));

		Report report = new Report();
		report.setAuthor(AUTHOR);
		report.setDepartment(DEPARMENT);
		report.setAddress(destAddress);
		report.setDate(new SimpleDateFormat("EEEE, dd MMMM yyyy").format(new Date()));
		report.setTime(new SimpleDateFormat("HH:MM:SS").format(new Date()));
		report.setPerformance(performance[choice - 1]);
		report.setPings(configProp.get("ping").toString());
		report.setTracers(configProp.get("traceroute").toString());
		report.setVersion("v1.0 Beta");
		report.setSource(InetAddress.getLocalHost().getHostAddress());
		report.setDestination(destAddress);
		report.setDescription(problemDescription);
		try {
			perfTestLogFile.write(TemplateEngine.buildContent(report, "template.vm"));
		} catch (Exception e1) {
			System.out.println(e1.getMessage());
		}
		
		Iterator<Future<PerfTestResult>> iterator = listOfTasks.iterator();
		int i=1;
		while (iterator.hasNext()) {
			Future<PerfTestResult> currTask = iterator.next();
			try {
				if (currTask.isDone()) {
					PerfTestResult result = currTask.get();
					String resultText = result.getResult();
					
					Report currReport = new Report();
					currReport.setIndex(i++);
					currReport.setResultType(extractCommand(resultText));
					currReport.setResultText(resultText);
					/*pingResult = resultText.split("\n");
					if(pingResult[0].indexOf("PING") != -1){
						String lastButOne = pingResult[pingResult.length-3];
						String timeTaken = lastButOne.substring(lastButOne.indexOf("time ") + 5, lastButOne.indexOf("ms"));
						currReport.setTotal(timeTaken);
						System.out.println(timeTaken);
						String[] stat = extracStatistics(resultText);
						currReport.setMin(stat[0]);
						currReport.setAvg(stat[1]);
						currReport.setMax(stat[2]);
						currReport.setMdev(stat[3]);
						currReport.setShowGraph("block");
					}else{
						currReport.setShowGraph("none");
					}*/
					
					perfTestLogFile.write(TemplateEngine.buildContent(currReport, "result.vm"));
					if (percent < 100) {
						update(percent++, 100);
					}
				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
		perfTestLogFile.write("</table><div class='footer'></div></body>");
		/*try{
			perfTestLogFile.write(TemplateEngine.buildContent(new Report(), "reportcircles.vm"));
		}catch(Exception e){
			System.out.println(e.getMessage());
		}*/
		perfTestLogFile.close();
		Long endTime = Calendar.getInstance().getTimeInMillis();
		double timeTaken = ((endTime - startTime) / 1000 / 60);
		System.out
				.println("\n[PerfTest] -----------------------------------------------------");
		System.out.println("[PerfTest] Report built successfully!");
		System.out.println("[PerfTest] Time taken: " + timeTaken
				+ " min");
		System.out
				.println("[PerfTest] -----------------------------------------------------");
		// System.out.println("Do you want to email this report?\n 1. Yes \n 2. No");
		scanIn.close();
	}

	/**
	 * 
	 */
	private static void checkAndCreateDefaultsProperties() {
		File file = new File("./config.properties");
		if (!file.exists()) {
			try {
				if (file.createNewFile()) {
					BufferedWriter bw = new BufferedWriter(new FileWriter(file));
					bw.write("ping=google.com,facebook.com,microsoft.com\rtraceroute=google.com,facebook.com,microsoft.com");
					bw.close();
				}
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
		}
		InputStream inStream;
		try {
			inStream = new FileInputStream(file);
			configProp.load(inStream);
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	/**
	 * @throws IOException
	 */
	private static void checkAndCreateLogFolder() throws IOException {
		String fileName;
		if (!Files.exists(
				FileSystems.getDefault().getPath(
						System.getProperty("user.home"), "PerfTest"),
				new LinkOption[] { LinkOption.NOFOLLOW_LINKS })) {
			try {
				Files.createDirectories(Paths.get(OSHome.getPerfTestPath()));
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
		} else {
			fileName = "PerfTest_"
					+ (new Date()).toString().replace(" ", "_")
							.replace(":", "_") + ".html";
			PerfTest.perfTestLogFile = Files.createFile(Paths.get(OSHome
					.getPerfTestPath() + "/" + fileName));
		}
	}

	public static void update(int done, int total) {
		char[] workchars = { '|', '/', '-', '\\' };
		String format = "\r%3d%% %s %c";

		int percent = (++done * 100) / total;
		int extrachars = (percent / 2) - PerfTest.progress.length();

		while (extrachars-- > 0) {
			progress.append('#');
		}

		System.out.printf(format, percent, progress, workchars[done
				% workchars.length]);

		if (done == total) {
			System.out.flush();
			System.out.println();
			init();
		}
	}

	private static void init() {
		PerfTest.progress = new StringBuilder(60);
	}

	private static String extractCommand(String result) {
		String[] type;
		if (result.indexOf('(') != -1) {
			type = result.substring(0, result.indexOf('(')).split(" ");
		} else {
			type = result.substring(0, result.indexOf(' ')).split(" ");
		}

		if (type[0].equalsIgnoreCase("PING")) {
			if(type[1].equals("9.182.116.118")){
				return "PING: Bangalore Domestic IP Address";
			}else if(type[1].equals("9.124.118.228")){
				return "PING: Pune Domestic IP Address";
			}else if(type[1].equals("9.17.137.11")){
				return "PING: w3.ibm.com IP Address";
			}
			return ("PING: " + type[1]);
		} else if (type[0].equalsIgnoreCase("traceroute")) {
			if(type[2].equals("9.182.116.118")){
				return "TRACEROUTE: Bangalore Domestic IP Address";
			}else if(type[2].equals("9.124.118.228")){
				return "TRACEROUTE: Pune Domestic IP Address";
			}else if(type[2].equals("9.17.137.11")){
				return "TRACEROUTE: w3.ibm.com IP Address";
			}
			return ("TRACEROUTE: " + type[2]);
		} else if (type[0].equalsIgnoreCase("eth0")) {
			return ("IPCONFIG");
		} else {
			return ("NETSTAT");
		}
	}
	
	private static String[] extracStatistics(String result){
		String statKey = "min/avg/max/mdev";
		String statBlock = pingResult[pingResult.length-2];
		String stat = statBlock.substring(statBlock.indexOf(statKey) + statKey.length() + 3, statBlock.lastIndexOf(" ms"));
		return stat.split("/");
	}

}